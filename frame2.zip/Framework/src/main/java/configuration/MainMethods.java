package configuration;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class MainMethods {

  WebDriver driver;
  WaitTypes wait = new WaitTypes(driver);
  Configuration config = new Configuration();

  public MainMethods(WebDriver driver) {
    this.driver = driver;
  }

  public WebElement getElement(String locator, String type) {
    type = type.toLowerCase();
    if (type.equals("id")) {
      System.out.println("Try to find element with locator id: " + locator);
      return this.driver.findElement(By.id(locator));
    } else if (type.equals("xpath")) {
      System.out.println("Try to find element with locator xpath: " + locator);
      return this.driver.findElement(By.xpath(locator));
    } else if (type.equals("cssSelector")) {
      System.out.println("Try to find element with locator css: " + locator);
      return this.driver.findElement(By.cssSelector(locator));
    } else if (type.equals("name")) {
      System.out.println("Try to find element with locator name: " + locator);
      return this.driver.findElement(By.name(locator));
    } else if (type.equals("linkText")) {
      System.out.println("Try to find element with locator linktext: " + locator);
      return this.driver.findElement(By.linkText(locator));
    } else if (type.equals("partialLinkText")) {
      System.out.println("Try to find element with locator partiallinktext: " + locator);
      return this.driver.findElement(By.partialLinkText(locator));
    } else if (type.equals("className")) {
      System.out.println("Try to find element with locator className: " + locator);
      return this.driver.findElement(By.className(locator));
    } else if (type.equals("tagName")) {
      System.out.println("Try to find element with locator tagName: " + locator);
      return this.driver.findElement(By.tagName(locator));
    } else {
      System.out.println("Locator type not supported");
      return null;
    }
  }

  public List < WebElement > getElementList(String locator, String type) {
    type = type.toLowerCase();
    if (type.equals("id")) {
      System.out.println("Try to find element with locator id: " + locator);
      return this.driver.findElements(By.id(locator));
    } else if (type.equals("xpath")) {
      System.out.println("Try to find element with locator xpath: " + locator);
      return this.driver.findElements(By.xpath(locator));
    } else if (type.equals("cssSelector")) {
      System.out.println("Try to find element with locator cssSelector: " + locator);
      return this.driver.findElements(By.cssSelector(locator));
    } else if (type.equals("name")) {
      System.out.println("Try to find element with locator name: " + locator);
      return this.driver.findElements(By.name(locator));
    } else if (type.equals("linkText")) {
      System.out.println("Try to find element with locator linkText: " + locator);
      return this.driver.findElements(By.linkText(locator));
    } else if (type.equals("partialLinkText")) {
      System.out.println("Try to find element with locator partialLinkText: " + locator);
      return this.driver.findElements(By.partialLinkText(locator));
    } else if (type.equals("className")) {
      System.out.println("Try to find element with locator className: " + locator);
      return this.driver.findElements(By.className(locator));
    } else if (type.equals("tagName")) {
      System.out.println("Try to find element with locator tagName: " + locator);
      return this.driver.findElements(By.tagName(locator));
    } else {
      System.out.println("Locator type not supported");
      return null;
    }
  }

  public boolean isElemenstPresent(String locator, String type) {
    List < WebElement > elementList = getElementList(locator, type);

    int size = elementList.size();

    if (size > 0) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * This method will open a new tab window.
   * 
   * @param browserWindow - provide a browser tab number where we want to switch.
   * @param url           - provide a destination URL.
   * @param element       - provide an element. The method will wait until this
   *                      element is displayed.
   */
  public void openNewBrowserTab(int browserWindow, String url, WebElement element) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      ((JavascriptExecutor) driver).executeScript("window.open()"); // We can open a new tab window using the
      // JavascriptExecutor.
      ArrayList < String > tabs = new ArrayList < String > (driver.getWindowHandles()); // Declare an ArrayList used for
      // different browser tabs.
      driver.switchTo().window(tabs.get(browserWindow)); // Switch to the selected browser tab.
      driver.get(url); // Navigate to URL.
      wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen.
    } catch (Exception e) {
      System.out.println("The operadion was not compleate. Please review the '" + methodName 
    		  + "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * This method is used for navigating to URL.
   * 
   * @param url     - provide a destination URL.
   * @param element - provide an element. The method will wait until this element
   *                is displayed.
   */
  public void navigateURL(String url, WebElement element) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      driver.get(url); // Navigate to URL.
      wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen.
    } catch (Exception e) {
      System.out.println("The operadion was not compleate. Please review the '" + methodName 
    		  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * This method is used for inputing text into the text element.
   * 
   * @param filledData - provide a data for filling the input text element.
   * @param element    - provide an element. The element should be input text
   *                   element.
   */
  public void fillWithText(String filledData, WebElement element) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      WebElement webElement = wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen
      // and assign it to the variable.
      webElement.clear(); // Clear the input text element.
      webElement.sendKeys(filledData); // Fill the input text element with data.
      String actualResult = webElement.getAttribute("value"); // Get the actual result string.
      Assert.assertEquals(actualResult, filledData); // Make an assertion to make sure that the method was
      // executed correctly.
    } catch (Exception e) {
      System.out.println("The operadion was not compleate. Please review the '" + methodName 
  			  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * This method is used for inputing text into the text element without clearing it before.
   * 
   * @param filledData - provide a data for filling the input text element.
   * @param element    - provide an element. The element should be input text element.
   */
  public void fillWithTextWithoutClearing(String filledData, WebElement element) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      WebElement webElement = wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen
      // and assign it to the variable.
      webElement.sendKeys(filledData); // Fill the input text element with data.
      String actualResult = webElement.getAttribute("value"); // Get the actual result string.
      Assert.assertEquals(actualResult, filledData); // Make an assertion to make sure that the method was
      // executed correctly.
    } catch (Exception e) {
      System.out.println("The operadion was not compleate. Please review the '" + methodName 
    		  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * Click using click() method.
   * 
   * @param element           - provide an element. The element will be used for click().
   * @param confirmElement	- provide an element. The method will wait until this element is displayed. 
   */
  public void clickMethod(WebElement element, WebElement confirmElement) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      if (element.isEnabled()) {
        WebElement webElement = wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen and assign it to the variable.
        webElement.click(); // Click over the element.
        wait.waitIsDisplayed(confirmElement); // Wait the WebElement to be displayed on the screen.
      } else {
        System.out.println("The element '" + element + "' is not enabled and can't be clicked.");
      }
    } catch (Exception e) {
      System.out.println("The operadion was not compleate. Please review the '" + methodName 
    		  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * Click using click() method.
   * 
   * @param element           - provide an element. The element will be used for click().
   * @param confirmElement	- provide an element. The method will wait until this element is displayed.
   */
  public void clickMethodOpenNewBrowserTab(int browserWindow, WebElement element, WebElement confirmElement) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      if (element.isEnabled()) {
        WebElement webElement = wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen and assign it to the variable.
        webElement.click(); // Click over the element.
        ArrayList < String > tabs = new ArrayList < String > (driver.getWindowHandles()); // Declare an ArrayList used for different browser tabs.
        driver.switchTo().window(tabs.get(browserWindow)); // Switch to the selected browser tab.
        wait.waitIsDisplayed(confirmElement); // Wait the WebElement to be displayed on the screen.
      } else {
        System.out.println("The element '" + element + "' is not enabled and can't be clicked.");
      }
    } catch (Exception e) {
        System.out.println("The operadion was not compleate. Please review the '" + methodName 
	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * Click using enter button.
   * 
   * @param element      		 - provide an element. The element will be used for click().
   * @param confirmElement   	 - provide an element. The method will wait until this element is displayed.
   */
  public void clickEnterButton(WebElement element, WebElement confirmElement) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      if (element.isEnabled()) {
        WebElement webElement = wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen and assign it to the variable.
        webElement.sendKeys(Keys.ENTER); // Press the 'enter' button against the element.
        wait.waitIsDisplayed(confirmElement); // Wait the WebElement to be displayed on the screen.
      } else {
        System.out.println("The element '" + element + "' is not enabled and can't be clicked.");
      }
    } catch (Exception e) {
        System.out.println("The operadion was not compleate. Please review the '" + methodName 
	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * Click mouse right button.
   * 
   * @param element    	     - provide an element. The element will be used for right click.
   * @param confirmElement   	 - provide an element. The method will wait until this element is displayed.
   */
  public void clickRightMouseButton(WebElement element, WebElement confirmElement) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      if (element.isEnabled()) {
        Actions actions = new Actions(driver); // Declare and instance of Actions.
        WebElement webElement = wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen and assign it to the variable.
        actions.contextClick(webElement).perform(); // Execute the right click of the mouse action over the element.
        wait.waitIsDisplayed(confirmElement); // Wait the WebElement to be displayed on the screen.
      } else {
        System.out.println("The element '" + element + "' is not enabled and can't be clicked.");
      }
    } catch (Exception e) {
        System.out.println("The operadion was not compleate. Please review the '" + methodName 
	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * Double click left button.
   * 
   * @param element      		  - provide an element. The element will be used for click().
   * @param confirmElement   	  - provide an element. The method will wait until this element is displayed.
   */
  public void doubleClickMouseLeftButton(String expectedResult, WebElement element, WebElement confirmElement) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      if (element.isEnabled()) {
        Actions actions = new Actions(driver); // Declare and instance of Actions.
        WebElement webElement = wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen and assign it to the variable.
        actions.doubleClick(webElement).perform(); // Execute the double click action of the left mouse against the element.
        wait.waitIsDisplayed(confirmElement); // Wait the WebElement to be displayed on the screen.
      } else {
        System.out.println("The element '" + element + "' is not enabled and can't be clicked.");
      }
    } catch (Exception e) {
        System.out.println("The operadion was not compleate. Please review the '" + methodName 
	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * Click using click() method for check boxes and radio buttons with verify if they ware checked.
   * 
   * @param element - provide an element. The element should be check box or radio button. The element will be click().
   */
  public void clickCheckBoxRadioButton(WebElement element) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      WebElement webElement = wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen and assign it to the variable.
      if (webElement.isEnabled()) { // We need to check if the element is enabled. If not - the element can't be clicked.
        webElement.click(); // Click over the element.
        if (!webElement.isSelected())
        {
        	System.out.println("The element '"+webElement+"' was not checked.");
        }
      } else {
        System.out.println("The element: " + element + " is disabled and can't be clicked."); // Show this message in the console output if the element is disabled.
      }
    } catch (Exception e) {
        System.out.println("The operadion was not compleate. Please review the '" + methodName 
	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }
  
  /**
   * Click using click() method for check boxes and radio buttons WITHOUT verify if they ware checked.
   * 
   * @param element - provide an element. The element should be check box or radio button. The element will be click().
   */
  public void clickCheckBoxRadioButtonWithoutVerify(WebElement element) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      WebElement webElement = wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen and assign it to the variable.
      if (webElement.isEnabled()) { // We need to check if the element is enabled. If not - the element can't be clicked.
        webElement.click(); // Click over the element.
      } else {
        System.out.println("The element: " + element + " is disabled and can't be clicked."); // Show this message in the console output if the element is disabled.
      }
    } catch (Exception e) {
        System.out.println("The operadion was not compleate. Please review the '" + methodName 
	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * Select drop-down list by visible text.
   * 
   * @param visibleText - provide a drop-down visible text value.
   * @param element     - provide an element. The element should be drop-down list.
   */
  public void selectDropDownListByVisibleText(String visibleText, WebElement element) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      if (element.isEnabled()) {
        Select dropDownList = new Select(wait.waitIsEnabled(element)); // Wait the WebElement to be displayed on the screen and assign it to the variable. Finally select the element, because we will use a drop-down menu.
        dropDownList.selectByVisibleText(visibleText); // Select the drop-down value by visible text. 
        WebElement dropDownSelectedOption = dropDownList.getFirstSelectedOption(); // Get the selected option and assign it to WebElement variable.
        String dropDownVlaue = dropDownSelectedOption.getText(); // Get the actual result string.
        Assert.assertEquals(dropDownVlaue, visibleText); // Make an assertion to make sure that the method was executed correctly.
      } else {
        System.out.println("The element '" + element + "' is not enabled and can't be clicked.");
      }
    } catch (Exception e) {
        System.out.println("The operadion was not compleate. Please review the '" + methodName 
	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * Select drop-down list by index.
   * 
   * @param index   - provide a drop-down index value.
   * @param element - provide an element. The element should be drop-down list.
   */
  public void selectDropDownListByIndex(int index, WebElement element) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      if (element.isEnabled()) {
        Select dropDownList = new Select(wait.waitIsEnabled(element)); // Wait the WebElement to be displayed on the screen and assign it to the variable. Finally select the element, because we will use a drop-down menu.
        List < WebElement > options = dropDownList.getOptions(); // Get all drop down list option values and assign them to the list.
        WebElement dropDownValue = options.get(index); // Get the selected option and assign it to WebElement variable.
        String expectedResult = dropDownValue.getText(); // Get the expected result value.
        dropDownList.selectByIndex(index); // Select the drop-down value by index.
        WebElement dropDownSelectedOption = dropDownList.getFirstSelectedOption(); // Get the selected option and assign it to WebElement variable.
        String actualResult = dropDownSelectedOption.getText(); // Get the actual result string.
        Assert.assertEquals(actualResult, expectedResult); // Make an assertion to make sure that the method was executed correctly.
      } else {
        System.out.println("The element '" + element + "' is not enabled and can't be clicked.");
      }
    } catch (Exception e) {
        System.out.println("The operadion was not compleate. Please review the '" + methodName 
	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * Select drop-down list by value.
   * 
   * @param value   - provide a drop-down attribute value.
   * @param element - provide an element. The element should be drop-down list.
   */
  public void selectDropDownListByValue(String value, WebElement element) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      if (element.isEnabled()) {
        Select dropDownList = new Select(wait.waitIsEnabled(element)); // Wait the WebElement to be displayed on the screen and assign it to the variable. Finally select the element, because we will use a drop-down menu.
        dropDownList.selectByValue(value); // Select the drop-down by value.
        WebElement dropDownSelectedOption = dropDownList.getWrappedElement();
        String dropDownVlaue = dropDownSelectedOption.getAttribute("value"); // Get the attribut value of the element.
        Assert.assertEquals(dropDownVlaue, value); // Make an assertion to make sure that the method was executed correctly.
      } else {
        System.out.println("The element '" + element + "' is not enabled and can't be clicked.");
      }
    } catch (Exception e) {
        System.out.println("The operadion was not compleate. Please review the '" + methodName 
	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * Select drop-down list by clicking.
   * 
   * @param selectorDropDownList - provide an element. The element should be drop-down list.
   * @param element              - provide an element. The element should be the drop-down list value.
   */
  public void selectDropDownListByClick(WebElement dropDownListElement, WebElement dropDownListValueElement) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    try {
      if (dropDownListElement.isEnabled()) {
        WebElement dropDownList = wait.waitIsDisplayed(dropDownListElement); // Wait the WebElement to be displayed on the screen and assign it to the variable.
        dropDownList.click(); // Click over the element.
        WebElement dropDownListValue = wait.waitIsDisplayed(dropDownListValueElement); // Wait the WebElement to be displayed on the screen and assign it to the variable.
        String expectedResult = dropDownListValue.getText(); // Get the drop-down value text. This will be used for expected result.
        dropDownListValue.click(); // Click over the element.
        Select selectDropDownList = new Select(dropDownListElement); // Select the drop-down list.
        WebElement dropDownSelectedOption = selectDropDownList.getFirstSelectedOption(); // Get the selected drop-down list value.
        String actualResult = dropDownSelectedOption.getText(); // Assign the selected drop-down list value to a variable. This will be used for actual result.
        Assert.assertEquals(actualResult, expectedResult); // Make an assertion, to make sure that the method was executed correctly.
      } else {
        System.out.println("The element '" + dropDownListElement + "' is not enabled and can't be clicked.");
      }
    } catch (Exception e) {
        System.out.println("The operadion was not compleate. Please review the '" + methodName 
	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
  }

  /**
   * Copy the text from element.
   * 
   * @param element - provide an element. The element should be used for getText().
   */
  public String getText(WebElement element) {
    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
    String className = this.getClass().getSimpleName(); // Get the name of the class.
    String text = "The text was not copied"; // We need this flag, to make sure that the text was copied.
    try {
      WebElement webElement = wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen and assign it to the variable.
      text = webElement.getText(); // Assign the text value to the variable.
      return text; // Return the text values.
    } catch (Exception e) {
        System.out.println("The operadion was not compleate. Please review the '" + methodName 
	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
    }
    return text;
  }
  

  /** 
   * Accept the Alert (pop-up window).
   * 
   * @param element			- provide an WebElement. The click() method on the element should open an alert window.
   * @param expectedReult	- provide a String that should be the alert text. This will be used for expected result.
   */
  public void AcceptTheAlert(WebElement element, String expectedReult) {
	    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
	    String className = this.getClass().getSimpleName(); // Get the name of the class.
	     try {
	    	 element.click(); // Click on the button to show the pop-up window.
	    	 WebDriverWait wait = new WebDriverWait(driver, config.timeOut); // Declare a wait.
	    	 wait.until(ExpectedConditions.alertIsPresent()); // Wait until the pop-up is present.
	    	 String getThePopUpText = driver.switchTo().alert().getText(); // Get the text of the pop-up window.
	    	 Assert.assertEquals(getThePopUpText, expectedReult); // Make an assertion to make sure that the pop-up is opened.
	    	 driver.switchTo().alert().accept(); // Press on the "OK" button of the pop-up window.
	     } catch (Exception e) {
	         System.out.println("The operadion was not compleate. Please review the '" + methodName 
	 	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
	     }
  }
   
  /** 
   * Dismiss the Alert (pop-up window).
   * 
   * @param element			- provide an WebElement. The click() method on the element should open an alert window.
   * @param expectedReult	- provide a String that should be the alert text. This will be used for expected result.
   */
  public void DismissTheAlert(WebElement element, String expectedReult) {
	    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
	    String className = this.getClass().getSimpleName(); // Get the name of the class.
	     try {
	    	 element.click(); // Click on the button to show the pop-up window.
	    	 WebDriverWait wait = new WebDriverWait(driver, config.timeOut); // Declare a wait.
	    	 wait.until(ExpectedConditions.alertIsPresent()); // Wait until the pop-up is present.
	    	 String getThePopUpText = driver.switchTo().alert().getText(); // Get the text of the pop-up window.
	    	 Assert.assertEquals(getThePopUpText, expectedReult); // Make an assertion to make sure that the pop-up is opened.
	    	 driver.switchTo().alert().dismiss(); // Press on the "Cancel" button of the pop-up window.
	     } catch (Exception e) {
	         System.out.println("The operadion was not compleate. Please review the '" + methodName 
	 	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
	     }
  }
  
  /** 
   * Accept the Alert (pop-up window).
   * 
   * @param element			- provide an WebElement. The click() method on the element should open an alert window.
   * @param expectedReult	- provide a String that should be the alert text. This will be used for expected result.
   * @param text			- provide a text. The text will be used to fill the pop-up window input text element.
   */
  public void fillWithTextInToTheAlert(WebElement element, String expectedReult, String text) {
	    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
	    String className = this.getClass().getSimpleName(); // Get the name of the class.
	     try {
	    	 element.click(); // Click on the button to show the pop-up window.
	    	 WebDriverWait wait = new WebDriverWait(driver, config.timeOut); // Declare a wait.
	    	 wait.until(ExpectedConditions.alertIsPresent()); // Wait until the pop-up is present.
	    	 String getThePopUpText = driver.switchTo().alert().getText(); // Get the text of the pop-up window.
	    	 Assert.assertEquals(getThePopUpText, expectedReult); // Make an assertion to make sure that the pop-up is opened.
	    	 driver.switchTo().alert().sendKeys(text); // Fill with the text into the alert window.
	    	 driver.switchTo().alert().accept(); // Press on the "OK" button of the pop-up window.
	     } catch (Exception e) {
	         System.out.println("The operadion was not compleate. Please review the '" + methodName 
	 	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
	     }
  }

  /** Check how many iFrames has the current page. */
  public int checkHowManyIframesThePageHas() {
	    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
	    String className = this.getClass().getSimpleName(); // Get the name of the class.
	    try {
	    	 int allIframesInThePage = driver.findElements(By.tagName("iframe")).size();
	    	 if(allIframesInThePage !=0 ) {
	    		 System.out.println("There is/are '"+allIframesInThePage+"' iFrame/s in this page.");
	    		 return allIframesInThePage;
	    	 }
	    	 else {
	    		 System.out.println("The page doesn't contains any iFrames.");
	    		 return 0;
	    	 }
	     } catch (Exception e) {
	         System.out.println("The operadion was not compleate. Please review the '" + methodName 
	 	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
	     }
	     return 0;
  }
  
  /**
   * This method will be used to switch to the iFrame by ID.
   * @param locatorId		- provide a locator ID. The locator should be of the iFrame element.
   * @param element			- provide a WebElement. The element should be located into the iFrame code. The WebElement should be used for waitIsDisplayed.
   */
  public void changeToIframeById(String locatorId, WebElement element) {
	    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
	    String className = this.getClass().getSimpleName(); // Get the name of the class.
	     try { 
	    	 driver.switchTo().frame(locatorId); // Switch to iFrame by ID.
	    	 wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen.
	     }
	     catch (Exception e) {
	         System.out.println("The operadion was not compleate. Please review the '" + methodName 
	 	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
	     }
  }
  
  /**
   * This method will be used to switch to the iFrame by Index.
   * @param locatorIdenx	- provide an index used for iFrame that we want to switch.
   * @param element			- provide a WebElement. The element should be located into the iFrame code. The WebElement should be used for waitIsDisplayed.
   */
  public void changeToIframeByIndex(int locatorIndex, WebElement element) {
	    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
	    String className = this.getClass().getSimpleName(); // Get the name of the class.
	     try { 
	    	 driver.switchTo().frame(locatorIndex); // Switch to iFrame by index.
	    	 wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen.
	     }
	     catch (Exception e) {
	         System.out.println("The operadion was not compleate. Please review the '" + methodName 
	 	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
	     }
  }
  
  /**
   * This method will be used to switch back from the iFrame to the default HTML page.
   * @param element			- provide a WebElement. The element should be located outside of the iFrame code. The WebElement should be used for waitIsDisplayed.
   */
  public void changeFromIframeToDefaultHTML(WebElement element) {
	    String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
	    String className = this.getClass().getSimpleName(); // Get the name of the class.
	     try { 
	    	 driver.switchTo().defaultContent(); // Switch to the default HTML page.
	    	 wait.waitIsDisplayed(element); // Wait the WebElement to be displayed on the screen.
	     }
	     catch (Exception e) {
	         System.out.println("The operadion was not compleate. Please review the '" + methodName 
	 	  			+ "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
	     }
  }
  

}