package configuration;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitTypes {
	WebDriver driver;

	public WaitTypes(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement waitVisibilityOfElementLocatedBy(By locator, int timeout) {
		WebElement element = null;
		try {
			System.out.println("We are waiting " + timeout + " seconds to load the element.");

			WebDriverWait wait = new WebDriverWait(driver, timeout);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			System.out.println("Element appeared on the page.");

		} catch (Exception e) {
			System.out.println("Element is not presented in the page.");
		}
		return element;
	}

	public WebElement waitElementToBeClickableBy(By locator, int timeout) {
		WebElement element = null;
		try {
			System.out.println("We are waiting " + timeout + " seconds to load the element.");

			WebDriverWait wait = new WebDriverWait(driver, timeout);
			element = wait.until(ExpectedConditions.elementToBeClickable(locator));
			System.out.println("Element appeared on the page.");

		} catch (Exception e) {
			System.out.println("Element is not presented in the page.");
		}
		return element;
	}

	// This wait can be used for checking if the element is displayed on the UI.
	public WebElement waitIsDisplayed(WebElement element) {
		try {
			element.isDisplayed();
			}
			catch (NoSuchElementException e) {
			throw new RuntimeException("The element is not DISPLAYED. Error message: "+e);
			}
		return element;
	}
	
	// This wait can be used for checking if the element is enabled or disabled.
	public WebElement waitIsEnabled(WebElement element) {
		try {
			element.isEnabled();
			}
			catch (NoSuchElementException e) {
			throw new RuntimeException("The element is not ENABLED. Error message: "+e);
			}
		return element;
	}
	
	// This wait can be used for checking if the element is selected or deselected.
	public WebElement waitIsSelected(WebElement element) {
		try {
			element.isSelected();
			}
			catch (NoSuchElementException e) {
			throw new RuntimeException("The element is not SELECTED. Error message: "+e);
			}
		return element;
	}

}
