package configuration;

public class Configuration {

	public int timeOut = 15;
	public String baseURL = "https://www.saucedemo.com/"; // Declare a base URL value.
	public String browser = "chrome"; // Declare used browser here. The values can be "chrome", "firefox"... (add another value if you add another driver to the automation)
}
