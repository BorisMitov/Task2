package pom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

public class SwangLabsPO {

	public WebDriver driver;
	public SoftAssert softassert = new SoftAssert();

  public SwangLabsPO(WebDriver driver) {
    this.driver = driver;
    PageFactory.initElements(driver, this); // we need this to be declare here. Without this we will not be able to use the @FindBy annotation.
  }

  // Declare a selectors here.
  @FindBy(id = "user-name")
  public WebElement userNameInputTextElement;
  
  @FindBy(id = "password")
  public WebElement passwordInputTextElement;
  
  @FindBy(id = "login-button")
  public WebElement loginButton;
  
  @FindBy(id = "shopping_cart_container")
  public WebElement shoppingContainer;
  
  @FindBy(xpath = "//h3[@data-test='error']")
  public WebElement errorMessageLockedOutUser;
  
  @FindBy(xpath = "//div[@class='inventory_item']")
  public List <WebElement> productItems;
  
  @FindBy(xpath = "//select[@class='product_sort_container']")
  public WebElement filterDropDownList;
  
  @FindBy(xpath = "//div[@class='inventory_item_price']")
  public List <WebElement> productsPrice;


  
  public void step3() {
      String methodName = new Object() {}.getClass().getEnclosingMethod().getName(); // Get the name of the current method.
      String className = this.getClass().getSimpleName(); // Get the name of the class.
      try {

    		List < String > subjects = new ArrayList < String > (); // Create a new array.
    		for (int i=0;i<productsPrice.size();i++) {
    			subjects.addAll(Arrays.asList(productsPrice.get(i).getText().substring(1))); // Add the collection to the array.
    		}
    			double productPriceFirst=Double.parseDouble(subjects.get(0));
    			double productPriceLast=Double.parseDouble(subjects.get(subjects.size()-1));
    			if (productPriceFirst<productPriceLast) {
    	  		System.out.println("Correct! The sorting option is workign as expected.");
    	  	}
    	  	else {
    	  		System.out.println("INCORRECT! The sorting option is NOT workign as expected.");
    	  		softassert.fail();
    	  	}
    	  
    	  
      } catch (Exception e) {
          System.out.println("The operadion was not compleate. Please review the '" + methodName +
              "' method from '" + className + "' class. Error message: " + e); // This message will be shown if something is gone wrong with the method.
      }
  }

  
 }