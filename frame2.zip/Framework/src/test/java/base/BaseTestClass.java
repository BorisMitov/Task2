package base;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.asserts.SoftAssert;
import com.github.javafaker.Faker;
import configuration.OtherMethods;
import configuration.WaitTypes;
import configuration.Configuration;
import configuration.MainMethods;

public class BaseTestClass {
	
	  public WebDriver driver; // Declare a WebDriver.
	  public MainMethods mainMethods; // Declare a MainMethods.
	  public OtherMethods otherMethods; // Declare a OtherMethods.
	  public Configuration config; // Declare a Configuration.
	  public WaitTypes wait; // Declare a wait.
	  public String url; // Declare a url.
	  public SoftAssert softassert;
	  public Faker faker;
	  public Random random;
	  	  
	  public void setUp(String endpoint) {
		  config = new Configuration(); // Declare a constructor for Configuration.
		  otherMethods = new OtherMethods(); // Declare a constructor for OtherMethods.
		  softassert = new SoftAssert(); // Declare an instance for softAssert.
		  faker = new Faker();
		  random = new Random();
		  if (config.browser == "firefox") {
			  driver = new FirefoxDriver(); // Create a new instance of Chrome driver. 
		  }
		  else if (config.browser == "chrome")
		  {
			  driver = new ChromeDriver(); // Create a new instance of FireFox driver.
		  }
		  mainMethods = new MainMethods(driver); // Declare a constructor for MainMethods.
		  wait = new WaitTypes(driver); // Declare a constructor for WaitTypes.
		  driver.manage().window().maximize(); // Set opened browser to 100% width and- 100% high.
		  driver.manage().timeouts().implicitlyWait(config.timeOut, TimeUnit.SECONDS); // Set Implicit Wait.	
		  url = config.baseURL + endpoint; // Set url.
	  }
	
	  public void terminate() {
		  driver.quit(); // Close the browser when the test is done.
	  }
}
