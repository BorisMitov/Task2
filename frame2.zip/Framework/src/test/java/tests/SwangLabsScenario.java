package tests;

import org.testng.annotations.Test;
import base.BaseTestClass;
import org.testng.annotations.BeforeClass;
import java.io.IOException;

import org.testng.annotations.AfterClass;
import pom.SwangLabsPO;

public class SwangLabsScenario extends BaseTestClass {
    private SwangLabsPO page; // Declare a page object model.
    private String endpoint = "";

    // Log in using 'standard_user' user.
    @Test(priority = 1)
    public void logInWithStandardUser() {
        // Declare variables.
        String standartUser = "standard_user";
        String password = "secret_sauce";
        String expectedUrlAfterLogin = config.baseURL + "inventory.html";


        // Steps to reproduce.
        /** 1. Navigate to: https://www.saucedemo.com . */
        mainMethods.navigateURL(url, page.userNameInputTextElement); // Navigate to URL.

        /** 2. Fill with 'standard_user' data into the "Username" input text element. */
        mainMethods.fillWithText(standartUser, page.userNameInputTextElement);

        /** 3. Fill with 'secret_sauce' data into the "Password" input text element. */
        mainMethods.fillWithText(password, page.passwordInputTextElement);

        /** 4. Press on the "LOGIN" button. */
        mainMethods.clickMethod(page.loginButton, page.shoppingContainer);

        // Assertions.
        softassert.assertEquals(driver.getCurrentUrl(), expectedUrlAfterLogin);
        softassert.assertAll();
    }

    // Log in using 'locked_out_user' user.
    @Test(priority = 2)
    public void logInWithLockedOutUser() {
        // Declare variables.
        String lockedOutUser = "locked_out_user";
        String password = "secret_sauce";
        String expectedErrorMessageLockedOutUser = "Epic sadface: Sorry, this user has been locked out.";


        // Steps to reproduce.
        /** 1. Navigate to: https://www.saucedemo.com . */
        mainMethods.navigateURL(url, page.userNameInputTextElement); // Navigate to URL.

        /** 2. Fill with 'locked_out_user' data into the "Username" input text element. */
        mainMethods.fillWithText(lockedOutUser, page.userNameInputTextElement);

        /** 3. Fill with 'secret_sauce' data into the "Password" input text element. */
        mainMethods.fillWithText(password, page.passwordInputTextElement);

        /** 4. Press on the "LOGIN" button. */
        mainMethods.clickMethod(page.loginButton, page.errorMessageLockedOutUser);
        

        // Assertions.
        softassert.assertEquals(page.errorMessageLockedOutUser.getText(), expectedErrorMessageLockedOutUser);
        softassert.assertAll();
    }
    
    // Log in using 'problem_user' user.
    @Test(priority = 3)
    public void logInWithProblemUser() {
        // Declare variables.
        String problemUser = "problem_user";
        String password = "secret_sauce";
        String expectedUrlAfterLogin = config.baseURL + "inventory.html";


        // Steps to reproduce.
        /** 1. Navigate to: https://www.saucedemo.com . */
        mainMethods.navigateURL(url, page.userNameInputTextElement); // Navigate to URL.

        /** 2. Fill with 'problem_user' data into the "Username" input text element. */
        mainMethods.fillWithText(problemUser, page.userNameInputTextElement);

        /** 3. Fill with 'secret_sauce' data into the "Password" input text element. */
        mainMethods.fillWithText(password, page.passwordInputTextElement);

        /** 4. Press on the "LOGIN" button. */
        mainMethods.clickMethod(page.loginButton, page.shoppingContainer);

        // Assertions.
        softassert.assertEquals(driver.getCurrentUrl(), expectedUrlAfterLogin);
        softassert.assertAll();
    }
    
    // Log in using 'performance_glitch_user' user.
    @Test(priority = 4)
    public void logInWithPerformanceGlitchUser() {
        // Declare variables.
        String performanceGlitchUser = "performance_glitch_user";
        String password = "secret_sauce";
        String expectedUrlAfterLogin = config.baseURL + "inventory.html";


        // Steps to reproduce.
        /** 1. Navigate to: https://www.saucedemo.com . */
        mainMethods.navigateURL(url, page.userNameInputTextElement); // Navigate to URL.

        /** 2. Fill with 'performance_glitch_user' data into the "Username" input text element. */
        mainMethods.fillWithText(performanceGlitchUser, page.userNameInputTextElement);

        /** 3. Fill with 'secret_sauce' data into the "Password" input text element. */
        mainMethods.fillWithText(password, page.passwordInputTextElement);

        /** 4. Press on the "LOGIN" button. */
        mainMethods.clickMethod(page.loginButton, page.shoppingContainer);

        // Assertions.
        softassert.assertEquals(driver.getCurrentUrl(), expectedUrlAfterLogin);
        softassert.assertAll();
    }
   
    // scenario2
    @Test(priority = 5)
    public void scenario2() {
    	/** 1. Log in with standard user. */
    	logInWithStandardUser();
    	/** 2. Select Price (low to high) value from the filter. */
    	mainMethods.selectDropDownListByValue("lohi",page.filterDropDownList);
    	/** 3. Verify that the filter is working as expected. */    	
     	page.step3();
    	
        // Assertions.
    	softassert.assertEquals(6, page.productItems.size()); // Verify that all 6 products are visible on the page.
        softassert.assertAll();
    }
    
    @BeforeClass
    public void beforeClass() {
        setUp(endpoint);
        page = new SwangLabsPO(driver);
    }

    @AfterClass
    public void afterClass() throws IOException {
        terminate();
    }
}